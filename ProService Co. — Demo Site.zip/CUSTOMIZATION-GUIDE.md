# FieldDash Client Customization Guide

Everything you need to customize and deploy a new client site in under 10 minutes.
No coding required — just find-and-replace the values below.

---

## Quick Reference — What to Change Per Client

| What | File | Find → Replace |
|---|---|---|
| Business name | `index.html` | `ProService Co.` → Client name |
| Phone number | `index.html` + `app.js` | `(321) 555-0100` → Client phone |
| Email address | `index.html` | `hello@proserviceco.com` → Client email |
| City / state | `index.html` | `Central Florida` → Client area |
| Service areas | `index.html` | Edit the `.area-chip` list |
| Services offered | `index.html` | Edit the services grid section |
| Review names / text | `index.html` | Edit the `.review-card` blocks |
| Accent color | `style.css` | `#f97316` → New hex color |
| Webhook URL | `app.js` | Set `CONFIG.webhookUrl` |
| Webhook key | `app.js` | Set `CONFIG.webhookKey` |

---

## Step-by-Step: Deploying a New Client

### Option A — Automated (recommended, takes 5 minutes)

1. Make sure Railway CLI is installed: `npm install -g @railway/cli`
2. Log in: `railway login`
3. Run the deploy script:

```bash
./new-client.sh "joes-roofing" "Joe's Roofing" "(407) 555-0000" "joe@joesroofing.com"
```

Done. The script:
- Clones the template
- Replaces the business name, phone, email, and generates a unique webhook key
- Deploys the full backend + frontend to Railway
- Saves the client's credentials and URL to `~/fielddash-clients.txt`

---

### Option B — Manual (step by step)

**1. Copy the template folder**
```
cp -r fielddash-template/ new-client-name/
cd new-client-name/
```

**2. Open `demo-site/index.html` and change:**

Find every instance of each value and replace:

```
ProService Co.        →   [Client Business Name]
(321) 555-0100        →   [Client Phone]
hello@proserviceco.com →  [Client Email]
Central Florida       →   [Client City/Region]
Orlando, Kissimmee... →   [Client Service Areas]
```

**3. Open `demo-site/app.js` and change:**

```javascript
const CONFIG = {
  webhookUrl: 'https://YOUR-CLIENT-DOMAIN.railway.app/api/webhook/booking',
  webhookKey: 'PASTE_KEY_FROM_FIELDDASH_SETTINGS',
  phone: '(407) 555-0000',
};
```

**4. Deploy the backend to Railway:**
- Go to [railway.app](https://railway.app)
- Click New Project → Deploy from GitHub (or drag the folder)
- It auto-detects Node.js and runs `npm start`

**5. Get the webhook key:**
- Log in to the deployed admin at `https://your-railway-url.app`
- Go to Settings & API → Create a new webhook key
- Copy it back into `app.js` → `CONFIG.webhookKey`

**6. Connect the client's custom domain:**
- In Railway: Settings → Custom Domain → Add `admin.clientdomain.com`
- In client's DNS: Add a CNAME pointing to the Railway URL

---

## Changing the Accent Color

The entire site uses one accent color (`#f97316` — orange). To change it for a client:

1. Open `style.css`
2. Find and replace all instances of `#f97316` with the new color
3. Also replace `#fb923c` (the hover shade — slightly lighter)
4. Also replace `#ea6d0e` (the active shade — slightly darker)

**Quick tool:** Use [ColorHexa](https://www.colorhexa.com) — enter the base color, grab the lighter/darker variants.

**Good colors by industry:**
| Industry | Accent | Notes |
|---|---|---|
| Roofing | `#ea580c` orange-red | Strong, urgent |
| Pool / Water | `#0891b2` teal-blue | Fresh, clean |
| HVAC | `#2563eb` royal blue | Tech, precision |
| Landscaping | `#16a34a` green | Nature, growth |
| General trades | `#f97316` orange | Energy, trust |
| Pressure washing | `#0284c7` sky blue | Clean |
| Electrical | `#ca8a04` gold-yellow | Power |

---

## Changing the Services

Each service card in `index.html` follows this pattern:

```html
<div class="service-card">
  <div class="service-icon service-icon--orange">
    <!-- SVG icon here -->
  </div>
  <h3>Service Name</h3>
  <p>Short description of the service.</p>
  <ul class="service-list" role="list">
    <li>Bullet point 1</li>
    <li>Bullet point 2</li>
    <li>Bullet point 3</li>
    <li>Bullet point 4</li>
  </ul>
  <a href="#book" class="service-cta">CTA Text →</a>
</div>
```

- Icon color classes: `service-icon--orange`, `service-icon--blue`, `service-icon--green`, `service-icon--red`
- To add a service: copy the block and change the text
- To remove a service: delete the entire `<div class="service-card">` block

Free SVG icons for services: [lucide.dev](https://lucide.dev) — copy the SVG code

---

## Changing the Booking Form Services Dropdown

In `index.html`, find the `<select id="service">` element and edit the `<option>` lines:

```html
<select id="service" name="service" required>
  <option value="" disabled selected>Select a service…</option>
  <option value="Roof Inspection">Roof Inspection</option>
  <!-- Add, remove, or rename options here -->
</select>
```

---

## The Admin Dashboard

Every client gets the full FieldDash admin at their backend URL:

- **URL:** `https://their-railway-url.app`
- **Default login:** `admin@bookingdash.com` / `admin1234`
- **First thing to do:** Change the password in Settings

### What the client can do in the admin:
| Feature | What it does |
|---|---|
| Bookings | See every form submission from the website |
| Leads | Track prospects through the sales pipeline |
| Clients | Store client history, job count, revenue |
| Finances | Create invoices, log expenses, track profit |
| Calendar | Schedule jobs, estimates, follow-ups |
| Settings | Manage webhook keys, seed demo data |

---

## Pricing Suggestion

| Item | Price |
|---|---|
| Setup fee (one-time) | $500 – $1,500 |
| Monthly hosting + support | $50 – $100/mo |
| Custom feature add-ons | $150/hr |
| Domain setup | Included in setup fee |

Your cost per client on Railway: ~$5–7/month
Your margin on the monthly fee: ~85–90%

---

## Files in This Project

```
demo-site/
├── index.html          ← The client-facing website (edit for each client)
├── style.css           ← All styles (change accent color here)
├── app.js              ← JS logic + webhook integration (set CONFIG here)
└── CUSTOMIZATION-GUIDE.md  ← This file

new-client.sh           ← Automated deployment script
```

---

## Getting Help

If anything breaks or you need a custom feature built, the entire codebase is
in plain HTML/CSS/JavaScript — any web developer can pick it up immediately.

The admin dashboard (FieldDash) is built with:
- Node.js / Express (backend)
- React (frontend)
- SQLite (database — zero setup, zero monthly DB cost)
- All standard technologies, no vendor lock-in
