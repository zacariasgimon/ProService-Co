#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  new-client.sh — Deploy a new FieldDash client site
#
#  USAGE:
#    ./new-client.sh "joes-roofing" "Joe's Roofing" "(407) 555-0000" "joe@joesroofing.com"
#
#  REQUIREMENTS:
#    - Git installed
#    - Railway CLI installed: npm install -g @railway/cli
#    - Logged in to Railway: railway login
#    - Your template repo URL (set TEMPLATE_REPO below)
# ═══════════════════════════════════════════════════════════════════

set -e   # Exit on any error

# ── YOUR SETTINGS — edit these once ─────────────────────────────
TEMPLATE_REPO="https://github.com/YOUR_USERNAME/fielddash-template.git"
AGENCY_EMAIL="you@youragency.com"
# ─────────────────────────────────────────────────────────────────

# ── ARGUMENTS ────────────────────────────────────────────────────
CLIENT_SLUG="${1}"          # e.g. "joes-roofing"      (URL-safe, no spaces)
CLIENT_NAME="${2}"          # e.g. "Joe's Roofing"     (display name)
CLIENT_PHONE="${3}"         # e.g. "(407) 555-0000"
CLIENT_EMAIL="${4}"         # e.g. "joe@joesroofing.com"
WORK_DIR="/tmp/deploy-${CLIENT_SLUG}"

# ── VALIDATE ─────────────────────────────────────────────────────
if [ -z "$CLIENT_SLUG" ] || [ -z "$CLIENT_NAME" ] || [ -z "$CLIENT_PHONE" ] || [ -z "$CLIENT_EMAIL" ]; then
  echo "❌  Usage: ./new-client.sh <slug> <name> <phone> <email>"
  echo "    Example: ./new-client.sh joes-roofing \"Joe's Roofing\" \"(407) 555-0000\" joe@joesroofing.com"
  exit 1
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Deploying FieldDash for: ${CLIENT_NAME}"
echo "  Slug: ${CLIENT_SLUG}"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ── STEP 1: Clone template ────────────────────────────────────────
echo "📦  Cloning template..."
rm -rf "${WORK_DIR}"
git clone "${TEMPLATE_REPO}" "${WORK_DIR}"
cd "${WORK_DIR}"

# Remove old git history and start fresh
rm -rf .git
git init
git add .
git commit -m "Init ${CLIENT_NAME}"

# ── STEP 2: Customize front-end ──────────────────────────────────
echo "🎨  Customizing front-end for ${CLIENT_NAME}..."

# Replace business name in index.html
sed -i "s/ProService Co\./${CLIENT_NAME}/g" demo-site/index.html
sed -i "s/ProServiceCo\./${CLIENT_NAME}/g" demo-site/index.html

# Replace phone number
sed -i "s/(321) 555-0100/${CLIENT_PHONE}/g" demo-site/index.html
sed -i "s/+13215550100/+1${CLIENT_PHONE//[^0-9]/}/g" demo-site/index.html

# Replace email
sed -i "s/hello@proserviceco\.com/${CLIENT_EMAIL}/g" demo-site/index.html

# Replace phone in app.js
sed -i "s/(321) 555-0100/${CLIENT_PHONE}/g" demo-site/app.js

# ── STEP 3: Generate webhook key ─────────────────────────────────
echo "🔑  Generating webhook key..."
WEBHOOK_KEY=$(openssl rand -hex 16)
echo "    Webhook key: ${WEBHOOK_KEY}"

# Inject webhook key into app.js
sed -i "s/YOUR_WEBHOOK_KEY_HERE/${WEBHOOK_KEY}/g" demo-site/app.js

# ── STEP 4: Deploy to Railway ─────────────────────────────────────
echo "🚀  Deploying to Railway..."
railway init --name "${CLIENT_SLUG}"
railway up --detach

# Get the Railway URL
RAILWAY_URL=$(railway open --url 2>/dev/null || echo "Check Railway dashboard")

# ── STEP 5: Set env var for webhook URL in app.js ─────────────────
echo "🔧  Configuring backend URL..."
sed -i "s|/api/webhook/booking|${RAILWAY_URL}/api/webhook/booking|g" demo-site/app.js

# Final commit
git add .
git commit -m "Configure ${CLIENT_NAME} deployment"
railway up

# ── DONE ──────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅  DEPLOYMENT COMPLETE"
echo ""
echo "  Client:       ${CLIENT_NAME}"
echo "  Admin URL:    ${RAILWAY_URL}"
echo "  Webhook key:  ${WEBHOOK_KEY}"
echo ""
echo "  ➜ Log in to the admin at: ${RAILWAY_URL}"
echo "    Email:    admin@bookingdash.com"
echo "    Password: admin1234"
echo ""
echo "  ⚠️  IMPORTANT — Do this now:"
echo "    1. Log in and change the admin password in Settings"
echo "    2. Add the webhook key in Settings > API Keys"
echo "    3. Point the client's domain to: ${RAILWAY_URL}"
echo "    4. Send the client their login credentials"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Save client record
echo "${CLIENT_SLUG}|${CLIENT_NAME}|${CLIENT_PHONE}|${CLIENT_EMAIL}|${RAILWAY_URL}|${WEBHOOK_KEY}" >> ~/fielddash-clients.txt
echo "  📋  Client saved to ~/fielddash-clients.txt"
echo ""
