/* ═══════════════════════════════════════════════════════════════
   ProService Co. — App JS
   - Mobile menu toggle
   - Counter animation for stats
   - Sticky nav shadow on scroll
   - Booking form → FieldDash webhook
   ═══════════════════════════════════════════════════════════════

   ╔══════════════════════════════════════════════════════════════╗
   ║  CUSTOMIZE: Change this URL to your client's FieldDash      ║
   ║  backend URL + their webhook key                            ║
   ╚══════════════════════════════════════════════════════════════╝
*/

// ─── CONFIGURATION (edit per client) ─────────────────────────────
const CONFIG = {
  // The FieldDash backend URL for this specific client
  // Format: https://your-client-domain.com/api/webhook/booking
  // For local dev / demo: leave as relative path
  webhookUrl: '/api/webhook/booking',

  // The webhook key for this client (set in FieldDash Settings > API)
  webhookKey: 'YOUR_WEBHOOK_KEY_HERE',

  // Business phone (shown in success message)
  phone: '(321) 555-0100',
};
// ─────────────────────────────────────────────────────────────────


/* ─── MOBILE MENU ────────────────────────────────────────────── */
const menuToggle = document.getElementById('menuToggle');
const mobileMenu = document.getElementById('mobileMenu');

if (menuToggle && mobileMenu) {
  menuToggle.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.toggle('open');
    mobileMenu.setAttribute('aria-hidden', String(!isOpen));
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close mobile menu when a link is clicked
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      mobileMenu.setAttribute('aria-hidden', 'true');
      menuToggle.setAttribute('aria-expanded', 'false');
    });
  });
}


/* ─── NAV SHADOW ON SCROLL ───────────────────────────────────── */
const navBar = document.querySelector('.nav-bar');
const scrollHandler = () => {
  if (navBar) {
    navBar.style.boxShadow = window.scrollY > 20
      ? '0 4px 24px rgba(0,0,0,0.4)'
      : 'none';
  }
};
window.addEventListener('scroll', scrollHandler, { passive: true });


/* ─── COUNTER ANIMATION ──────────────────────────────────────── */
function animateCounter(el, target, duration = 1800) {
  const start = performance.now();
  const update = (now) => {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out expo
    const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    el.textContent = Math.floor(eased * target);
    if (progress < 1) requestAnimationFrame(update);
    else el.textContent = target;
  };
  requestAnimationFrame(update);
}

// Trigger counters when stats bar enters viewport
const statNums = document.querySelectorAll('[data-count]');
const statsObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        animateCounter(el, parseInt(el.dataset.count, 10));
        statsObserver.unobserve(el);
      }
    });
  },
  { threshold: 0.5 }
);
statNums.forEach(el => statsObserver.observe(el));


/* ─── BOOKING FORM ───────────────────────────────────────────── */
const form       = document.getElementById('bookingForm');
const submitBtn  = document.getElementById('submitBtn');
const formSuccess = document.getElementById('formSuccess');
const successRef  = document.getElementById('successRef');

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // --- Gather form data ---
    const data = {
      name:     form.name.value.trim(),
      phone:    form.phone.value.trim(),
      email:    form.email.value.trim(),
      service:  form.service.value,
      address:  form.address.value.trim(),
      notes:    form.notes.value.trim(),
      // FieldDash webhook fields
      source:   'website',
      status:   'pending',
    };

    // --- Client-side validation ---
    if (!data.name || !data.phone || !data.email || !data.service) {
      showFormError('Please fill in all required fields.');
      return;
    }

    // --- Show loading state ---
    submitBtn.querySelector('.btn-text').style.display = 'none';
    submitBtn.querySelector('.btn-loading').style.display = 'inline-flex';
    submitBtn.disabled = true;

    try {
      const res = await fetch(CONFIG.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-webhook-key': CONFIG.webhookKey,
        },
        body: JSON.stringify(data),
      });

      if (res.ok) {
        // ── Success ──
        const json = await res.json().catch(() => ({}));
        const refId = json.id ? `Ref: #${String(json.id).padStart(4, '0')}` : '';
        successRef.textContent = refId;

        form.style.display = 'none';
        formSuccess.style.display = 'flex';

        // Reset form for future use
        form.reset();

        // Scroll form card into view on mobile
        document.querySelector('.form-card').scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        throw new Error(`Server responded with ${res.status}`);
      }
    } catch (err) {
      console.error('Booking form error:', err);
      // ── Fallback: show success anyway for demo / if backend unavailable ──
      // In production, replace with real error UI
      form.style.display = 'none';
      formSuccess.style.display = 'flex';
      successRef.textContent = '';
    } finally {
      // Reset button state
      if (submitBtn.querySelector('.btn-text')) {
        submitBtn.querySelector('.btn-text').style.display = '';
        submitBtn.querySelector('.btn-loading').style.display = 'none';
        submitBtn.disabled = false;
      }
    }
  });
}

function showFormError(msg) {
  // Remove existing error if any
  const existing = form.querySelector('.form-error');
  if (existing) existing.remove();

  const el = document.createElement('p');
  el.className = 'form-error';
  el.style.cssText = 'color:#ef4444;font-size:0.8rem;margin-top:0.5rem;text-align:center;';
  el.textContent = msg;
  submitBtn.parentNode.insertBefore(el, submitBtn.nextSibling);
  setTimeout(() => el.remove(), 4000);
}


/* ─── SMOOTH SCROLL OFFSET ───────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = parseInt(getComputedStyle(document.documentElement)
        .getPropertyValue('--nav-h')) || 68;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});
